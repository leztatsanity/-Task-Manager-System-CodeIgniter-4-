<form action="/upload" method="post" enctype="multipart/form-data">
    <input type="file" name="upload_file" required>
    <button type="submit">Upload</button>
</form>
